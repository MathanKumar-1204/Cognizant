
public class BytecodeExample {
    public void exampleMethod() {
        System.out.println("Hello, Bytecode!");
    }
}
