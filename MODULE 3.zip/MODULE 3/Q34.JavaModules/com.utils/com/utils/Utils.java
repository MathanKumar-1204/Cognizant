package com.utils;

public class Utils {
    public static String getMessage() {
        return "Hello from com.utils!";
    }
}
