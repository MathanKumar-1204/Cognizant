public class DataTypeDemonstration {
    public static void main(String[] args) {
        int intValue = 10;
        float floatValue = 10.5f;
        double doubleValue = 20.5;
        char charValue = 'A';
        boolean booleanValue = true;
        System.out.println("int: " + intValue);
        System.out.println("float: " + floatValue);
        System.out.println("double: " + doubleValue);
        System.out.println("char: " + charValue);
        System.out.println("boolean: " + booleanValue);
    }
}
